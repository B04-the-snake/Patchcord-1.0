﻿using ChatClient.MVVM.Core;
using ChatClient.MVVM.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

#nullable disable

namespace ChatClient.MVVM.ViewModel
{
    class MainViewModel : ObservableObject
    {
        public ObservableCollection<UserModel> Users { get; set; }
        public ObservableCollection<MessageModel> Messages { get; set; }

        /* Komendy */

        public RelayCommand SendCommand { get; set; }

        private UserModel _selectedContact;

        public UserModel SelectedContact
        {
            get { return _selectedContact; }
            set 
            { 
                _selectedContact = value;
                OnPropertyChanged();
            }
        }

        private string _message;
        public string Message
        {
            get { return _message; }
            set 
            { 
                _message = value;
                OnPropertyChanged();
            }
        }


        public MainViewModel()
        {
            Users = new ObservableCollection<UserModel>();
            Messages = new ObservableCollection<MessageModel>();

            SendCommand = new RelayCommand(o =>
            {
                Messages.Add(new MessageModel
                {
                    Message = Message,
                    FirstMessage = false
                });

                Message = "";
            });


            Messages.Add(new MessageModel
            {
                Username = "Black Jack",
                UsernameColor = "#409AFF",
                ImageSource = "https://cdn.pixabay.com/photo/2018/08/28/13/29/avatar-3637561_1280.png",
                Message = "Hello, there!",
                Time = DateTime.Now,
                IsNativeOrigin = false,
                FirstMessage = true,

            });

            for (int i = 0; i < 3; i++)
            {
                Messages.Add(new MessageModel
                {
                    Username = "Bob The Builder",
                    UsernameColor = "#409AFF",
                    ImageSource = "https://cdn.pixabay.com/photo/2017/06/28/13/57/occupation-2450708_1280.png",
                    Message = "Hello, there!",
                    Time = DateTime.Now,
                    IsNativeOrigin = false,
                    FirstMessage = false,
                });
            }

            Messages.Add(new MessageModel
            {
                Username = "Bob The Builder",
                UsernameColor = "#409AFF",
                ImageSource = "https://cdn.pixabay.com/photo/2017/06/28/13/57/occupation-2450708_1280.png",
                Message = "Hello, everyone!",
                Time = DateTime.Now,
                IsNativeOrigin = false,
                FirstMessage = false,
            });

            for (int i = 0; i < 4; i++)
            {
                Messages.Add(new MessageModel
                {
                    Username = "Bob The Builder",
                    UsernameColor = "#409AFF",
                    ImageSource = "https://cdn.pixabay.com/photo/2017/06/28/13/57/occupation-2450708_1280.png",
                    Message = "Wazzup, guys?",
                    Time = DateTime.Now,
                    IsNativeOrigin = true,
                });
            }


            Messages.Add(new MessageModel
            {
                Username = "Black Jack",
                UsernameColor = "#409AFF",
                ImageSource = "https://cdn.pixabay.com/photo/2018/08/28/13/29/avatar-3637561_1280.png",
                Message = "Hello, there!",
                Time = DateTime.Now,
                IsNativeOrigin = true,
                
            });

            for (int i = 0; i < 5; i++)
            {
                Users.Add(new UserModel
                {
                    Username = $"Gambler {i}",
                    ImageSource = "https://cdn.pixabay.com/photo/2017/06/10/23/00/men-2391047_1280.png",
                    Messages = Messages
                });
            }
        }

    }
}
